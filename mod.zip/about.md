# mod by user95401

no description

## <co>Converted for Geode</c>
---

<cr>This is traditional mod that uses minhook!

BUT! In general, this mod works, and IN MOST CASES IT is COMPATIBLE.</c>
