# v1.1.0

 * Removed Herobrine

# v1.0.1

 * Fixed bugs

# v1.0.0

 * Initial release
